// SDSC Summer Institute 2018
// Andreas Goetz (agoetz@sdsc.edu)

// Hello World Program in C

#include<stdio.h>

int main(void) {

  printf("Hello World!\n");
  return 0;

}
